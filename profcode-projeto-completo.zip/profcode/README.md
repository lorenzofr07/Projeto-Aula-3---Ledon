# ProfCode

Projeto acadêmico desenvolvido para a disciplina de Desenvolvimento Front-End para Web.

## Sobre o projeto

A ProfCode é um site para divulgação de aulas de programação com diferentes linguagens.

O projeto possui:

- Página inicial;
- Página sobre o projeto;
- Página de aulas;
- Página de contato;
- Formulário de contato;
- Layout responsivo;
- HTML e CSS;
- Publicação pelo GitHub Pages.

## Estrutura

```text
profcode/
│
├── index.html
├── sobre.html
├── aulas.html
├── contato.html
├── README.md
│
└── css/
    └── style.css
```

## Tecnologias utilizadas

- HTML5
- CSS3
- Git
- GitHub
- GitHub Pages

## Publicação

Depois de enviar os arquivos para o GitHub:

1. Entre no repositório.
2. Acesse Settings.
3. Acesse Pages.
4. Em Source, selecione a branch `main`.
5. Clique em Save.
6. Aguarde a publicação do site.

O endereço normalmente ficará no formato:

`https://SEU-USUARIO.github.io/NOME-DO-REPOSITORIO/`

## Projeto acadêmico

ProfCode - Desenvolvimento Front-End para Web.
